/*
 * Name: Subhrajit Das
 * Roll: 23210106
 * Mail: subhrajit.das@iitgn.ac.in
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/*
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded.
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{

    int i, j, row, col;
    int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
    // total 12 local variables of this function

    /*
     * Dividing the whole matrice into sub matrices.
     * For 32x32 8x8 submatrices are taken
     * For 64x64 8x8 submatrices are further divided into 4x4 submatrices.
     * For 61x67 16x16 submatrices are taken
     */

    // for 64x64, transpose is done differently.
    // each 8x8 submatrix's 4x4 submatrix is transposed manually for cache efficiency
    if (N == 64)
    {
        // colum-major access of 8x8 submatrices
        for (j = 0; j < M; j += 8) {
            for (i = 0; i < N; i += 8) {

                // manual work for cache efficiency

                for (row = i; row < i + 4; row++) {
                    temp0 = A[row][j];
                    temp1 = A[row][j + 1];
                    temp2 = A[row][j + 2];
                    temp3 = A[row][j + 3];
                    temp4 = A[row][j + 4];
                    temp5 = A[row][j + 5];
                    temp6 = A[row][j + 6];
                    temp7 = A[row][j + 7];
                    B[j][row] = temp0;
                    B[j + 1][row] = temp1;
                    B[j + 2][row] = temp2;
                    B[j + 3][row] = temp3;
                    B[j][row + 4] = temp4;
                    B[j + 1][row + 4] = temp5;
                    B[j + 2][row + 4] = temp6;
                    B[j + 3][row + 4] = temp7;
                }
                for (col = j; col < j + 4; col++) {

                    // Temporarily store Bottom Left 4x4 part of 8x8 submatrix of A
                    temp4 = A[i + 4][col];
                    temp5 = A[i + 5][col];
                    temp6 = A[i + 6][col];
                    temp7 = A[i + 7][col];

                    // Temporarily store Top Right 4x4 part of 8x8 submatrix of B
                    temp0 = B[col][i + 4];
                    temp1 = B[col][i + 5];
                    temp2 = B[col][i + 6];
                    temp3 = B[col][i + 7];

                    // Replace B's Top Right with A's Bottom Left
                    B[col][i + 4] = temp4;
                    B[col][i + 5] = temp5;
                    B[col][i + 6] = temp6;
                    B[col][i + 7] = temp7;

                    // Replace B's Bottom Left with A's Top Right
                    B[col + 4][i] = temp0;
                    B[col + 4][i + 1] = temp1;
                    B[col + 4][i + 2] = temp2;
                    B[col + 4][i + 3] = temp3;

                    // Replace B's Bottom Right with A's Top Left Directly
                    B[col + 4][i + 4] = A[i + 4][col + 4];
                    B[col + 4][i + 5] = A[i + 5][col + 4];
                    B[col + 4][i + 6] = A[i + 6][col + 4];
                    B[col + 4][i + 7] = A[i + 7][col + 4];
                }
            }
        }
        return;
    }

    /*
     * temp0 will contain sub matrix size
     * temp1 will contain the diagonal elements
     * temp2 will contain the row number of corressponding diagonal element
     */

    if (N == 32)
        temp0 = 8;                    // for 32x32 we're dividing the matrix into 8x8 blocks
    else
        temp0 = 16;                   // for 61x67 we're dividing the matrix into 16x16 blocks at max

    // acessing sub-matrices in column-major order
    for (j = 0; j < M; j += temp0) { // j controls the sub-matrix column wise starting point
        for (i = 0; i < N; i += temp0) { // j controls the sub-matric row wise starting point
            // accessing elements in row-major order in each sub-matrice
            for (row = i; row < i + temp0 && row < N; row++) { // row takes the lead from i, and takes 8 successive rows within max row limit
                for (col = j; col < j + temp0 && col < M; col++) { // col takes the lead from j, and takes 8 successive coloumns with max col limit
                    // doing this operation if it's not diagonal element
                    if (row != col)
                        B[col][row] = A[row][col]; // sub-matrix transpose, storing it to B as we can't change A
                    else{
                            temp1 = A[row][col]; // if its a diagonal element, we're storing it to temp1 such that it doesn't unnecessarily cause cache eviction of B
                            temp2 = row;         // storing the row number for which the diagonal element is temporarily stored
                    }
                }
                // for each row there will be only one diagonal element
                // and diagonal element comes with starting element of diagonal sub-matrices
                if (i == j)
                    B[temp2][temp2] = temp1;
            }
        }
    }
}

/*
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started.
 */

/*
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }
}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc);

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc);
}

/*
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++)
    {
        for (j = 0; j < M; ++j)
        {
            if (A[i][j] != B[j][i])
            {
                return 0;
            }
        }
    }
    return 1;
}

