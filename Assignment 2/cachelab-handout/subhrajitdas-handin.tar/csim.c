/*
 * Name: Subhrajit Das
 * Roll: 23210106
 * Mail: subhrajit.das@iitgn.ac.in
 */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include "cachelab.h" 

/* variables to store the count of hit, miss and eviction */
int hit_count = 0, miss_count = 0, evict_count = 0;

/* set maximum word length to 8*size of long */
const int maxWordLength = sizeof(long)<<3;

/* flags to parse command line arguments */
int v_flag = 0, h_flag = 0;

/* s: # set index bits
 * b: # block bits
 * E: set associativity
*/
int s, b, E, tagBits;	

/*
 *
 *  Implementation of Cache Data Structure
 *
 *	
 *	Cache is implemented through Linked List of 2^s Sets, which stores a pointer to head set.
 *	Each E-way Set is also implemented through Linked List of only valid lines.
 *  
 *
 * 	The linked list of lines is in the order from most recently used to least recently used.
 * That is, most recently used line is pointed by head, and least recently line is at the tail.
 *
 * 	If there is a miss in the target set of the cache, it adds a line at head.
 *  If there is a hit, it moves the matching line to the head of the target set.
 * 	When there's a capacity miss (i.e. size exceeds E within a set), it deletes the last line (i.e. LRU line).
 *
 *
 */

/* structure for implementing Line of a cache */
struct Line {
	int valid ;				// if 1 then the line is valid, otherwise invalid
	unsigned tag ;			// stores tag part
	struct Line *next;		// points to the next line
};

/* structure for implementing Set of a cache */
struct Set {
	struct Line *linePtr;	// points to the starting line of a set
	struct Set *next;		// points to the next set
};

/* structure for implementing a set-associative cache */
struct Cache {
	struct Set *setPtr;
};

/* return the number of valid lines in a set*/
int setSize(struct Set *set){
	struct Line *temp = set->linePtr;
	int size = 0;
	while (temp != NULL){
		++size;
		temp = temp->next;
	}
	return size;
}

/* create set with capacity E and no valid lines */
void createSet(struct Set *set){
	set->linePtr = NULL;
	set->next = NULL;
}

/* create cache with 2^s empty sets*/
void createCache(struct Cache *cache) {
	struct Set *newSet = (struct Set*)malloc(sizeof(struct Set));
	if (newSet==NULL){
		if(v_flag)
			printf("Error: memory for set can't be created, malloc failure!");
		exit(-1);
	}
	createSet(newSet);
	cache->setPtr= newSet;
	int i;
	for (i = 1; i < (1 << s); ++i){
		struct Set *nextSet = (struct Set*)malloc(sizeof(struct Set));
		if (nextSet==NULL){
			if(v_flag)
				printf("Error: memory for set can't be created, malloc failure!");
			exit(-1);
		}
		createSet(nextSet);
		newSet->next = nextSet;
		newSet = nextSet;
	}
}

/* remove the last line of a set */
void removeLastLine(struct Set *set){
	struct Line *current = set->linePtr;
	struct Line *prev1 = NULL;
	struct Line *prev2 = NULL;
	while (current != NULL){
		prev2 = prev1;
		prev1 = current;
		current = current->next;
	}
	if (prev2 != NULL)
		prev2->next = NULL;
	else
		set->linePtr = NULL;
	if (prev1 != NULL)
		free(prev1);
}

/* insert a (valid) line to the head of a set, evict when exceeds capacity */
void insertLineAtHead(struct Set *set, struct Line *line){
	if (setSize(set) == E){
		removeLastLine(set);
		evict_count++;
		if (v_flag)
			printf("eviction ");
	}
	line->next = set->linePtr;
	set->linePtr = line;
}

/* move the matched line to head of the set */
void moveLineToHead(struct Set *set, struct Line *line, struct Line *prev){
	if (prev != NULL){
		prev->next = line->next;
		line->next = set->linePtr;
		set->linePtr = line;
	}
}

/* the procedure of fetching an address in the cache */
void accessCache(struct Cache *cache, unsigned address){
	int tag_bits = address >> (s+b);
	int set_bits = (address << tagBits) >> (tagBits+b);

	/* move to targetSet according to set_bits */
	struct Set *targetSet = cache->setPtr;
	int i;
	for (i = 0; i < set_bits; ++i)
		targetSet = targetSet->next;

	struct Line *ln = targetSet->linePtr;
	struct Line *prev = NULL;
	while (ln != NULL){
		/* hit */
		if (ln->valid && (ln->tag == tag_bits)){
			hit_count++;
			if (v_flag)
				printf("hit ");
			moveLineToHead(targetSet, ln, prev);
			return ;
		}
		prev = ln;
		ln = ln->next;	
	}

	/* miss if no match, add a new line */
	/* possible eviction happens in insertLineAtHead */
	miss_count++;
	if (v_flag)
		printf("miss ");
	struct Line *newLine = (struct Line *)malloc(sizeof(struct Line));
	if (newLine==NULL){
		if(v_flag)
			printf("Error: memory for set can't be created, malloc failure!");
		exit(-1);
	}
	newLine->valid = 1;
	newLine->tag = tag_bits;
	insertLineAtHead(targetSet,newLine);
}

/* free cache, every set of cache, and every line in set */
void freeCache(struct Cache *cache){
	struct Set *setTobeFreed = cache->setPtr;
	while (!setTobeFreed){
		struct Line *lineToBeFreed = setTobeFreed->linePtr;
		while (!lineToBeFreed){
			struct Line *tempLine = lineToBeFreed->next;
			free(lineToBeFreed);
			lineToBeFreed = tempLine;
		}
		struct Set *tempSet = setTobeFreed->next;
		free(setTobeFreed);
		setTobeFreed = tempSet;
	}
	free(cache);
}

int main(int argc, char** argv){	
	int option, size;
	char typeOfAcess;
	unsigned addr;
	char *trace;

	/* parse flag commands */
	while(-1 != (option = getopt(argc, argv, "vhs:E:b:t:"))) {
		switch(option) {
			case 'v':
				v_flag = 1;
				break;
			case 'h':
				h_flag = 1;
				break;
			case 's':
				s = atoi(optarg);
				if(s < 0 && s > maxWordLength ){
					printf("Error: s value exceeds the range [0, word_length].\n");
					exit(-1);
				}
				break;
			case 'E':
				E = atoi(optarg);
				if(E <= 0){
					printf("Error: E value must be > 0.\n");
					exit(-1);
				}
				break;
			case 'b':
				b = atoi(optarg);
				if(b < 0 || b > maxWordLength){
					printf("Error: b value exceeds the range [0, word_length].\n");
					exit(-1);
				}
				break;
			case 't':
				trace = optarg;
				break;
			default:
				break;
		}
	}
	/* Initialize the tag bits */
	tagBits = maxWordLength - s - b;

	/* Try to create the cache */
	struct Cache *cache = (struct Cache *)malloc(sizeof(struct Cache));
	if (cache==NULL){
		if (v_flag)
			printf("Error: Can't create the cache due to memory constraints, malloc failure.\n");
		return -1;
	}
	createCache(cache);

	/* read trace file and access cache */
	FILE *traceFile;
	traceFile = fopen(trace, "r");
	if (!traceFile){
		fprintf(stderr, "Error: Trace file cannot be opened.\n");
		return -1;
	} 
	while(fscanf(traceFile, "%c %x, %d", &typeOfAcess, &addr, &size) > 0) {
		if (v_flag)
			printf("%c %x, %d ", typeOfAcess, addr, size);
		switch(typeOfAcess){
			case 'L':
				// Simulate Data Load
				accessCache(cache, addr);
				break;
			case 'S':
				// Simulate Data Store
				accessCache(cache, addr);
				break;
			case 'M':
				// Simulate Data Modify: Load followed by Store
				accessCache(cache, addr);
				accessCache(cache, addr);
				break;
			default:
				break;
		}
		if (v_flag)
			printf("\n");
	}
	fclose(traceFile);

	freeCache(cache);
	printSummary(hit_count, miss_count, evict_count);

	return 0; 
}

